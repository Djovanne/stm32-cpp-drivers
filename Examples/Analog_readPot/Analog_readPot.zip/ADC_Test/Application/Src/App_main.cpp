/*
 * App_main.cpp
 *
 *  Created on: Jan 23, 2026
 *      Author: giova
 *
*   Esse teste ilustra o uso do conversosr analógico-digital, tanto no modo polling (seletivo), quanto no DMA
*   O DMA é ativado no MX -> Analog -> ADC1,
*     - selecione os pinos dos canais que serão utilizados (IN0, IN1, IN2 e etc.)
*     - habilite o Scan mode (para percorer os demais pinos, caso tenha mais de um_
*     - habilite o continuous mode (para ele não parar de ler ao terminar de medir o último pino)
*     - habilite o DMA no modo circular (sefor usalo, claro)
*  	Esse teste foi feito utilizando a resolução de 12 bits, caso mude, atualize o define
*  	A temperatura medida é a do sensor interno do chip, e o calculo foi retirado do "Reference Manual" do F411CEU6
*  	Cada modo pode ser testado comentando e descomentando os defines "ACDDMA" e "POLLING"
*
 */



#include "App_main.h"
#include "main.h"
#include <stdio.h>
#include <math.h>

//#define POLLING
#define ADCDMA

#define RESOLUTION ((1UL<<12)-1)
#define VREF            3.3f
#define V25             0.76f
#define AVG_SLOPE       0.0025f
#define TEMP_REF       25.0f

extern ADC_HandleTypeDef hadc1;

uint16_t adc[4];
float tension[3];

float temperature;
float avgslope = 0.0025;
float med;

int app_main()
{
	//para inicializar o USB
	HAL_Delay(100);

	#ifdef POLLING
		while(1)
		{
			HAL_ADC_Start(&hadc1);
			HAL_ADC_PollForConversion(&hadc1, 100);
			adc[0] = HAL_ADC_GetValue(&hadc1);

			HAL_ADC_PollForConversion(&hadc1, 100);
			adc[1] = HAL_ADC_GetValue(&hadc1);

			HAL_ADC_PollForConversion(&hadc1, 100);
			adc[2] = HAL_ADC_GetValue(&hadc1);

			HAL_ADC_PollForConversion(&hadc1, 100);
			adc[3] = HAL_ADC_GetValue(&hadc1);
			HAL_ADC_Stop(&hadc1);

			tension[0] = adc[0]*VREF/(RESOLUTION);
			tension[1] = adc[1]*VREF/(RESOLUTION);
			tension[2] = adc[2]*VREF/(RESOLUTION);
			med = adc[3]*VREF/(RESOLUTION);
			temperature = (med - V25)/avgslope + TEMP_REF;

			printf("\n\r Valor leitura0 = %d\n\r", adc[0]);
			printf("\n\r Valor leitura1 = %d\n\r", adc[1]);
			printf("\n\r Valor leitura2 = %d\n\r", adc[2]);
			printf("Valor Convertido da bateria0 = %.2f\n\r", tension[0]);
			printf("Valor Convertido da bateria1 = %.2f\n\r", tension[1]);
			printf("Valor Convertido da bateria2 = %.2f\n\r", tension[2]);
			printf("Temperatura = %.2f\n\r", temperature);


			HAL_Delay(50);
		}
	#endif

	#ifdef ADCDMA
		HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc, 4);
		while(1)
		{
			tension[0] = adc[0]*VREF/(RESOLUTION);
			tension[1] = adc[1]*VREF/(RESOLUTION);
			tension[2] = adc[2]*VREF/(RESOLUTION);
			med = adc[3]*VREF/(RESOLUTION);
			temperature = (med - V25)/avgslope + TEMP_REF;

			printf("\n\r Valor leitura0 = %d\n\r", adc[0]);
			printf("\n\r Valor leitura1 = %d\n\r", adc[1]);
			printf("\n\r Valor leitura2 = %d\n\r", adc[2]);
			printf("Valor Convertido da bateria0 = %.2f\n\r", tension[0]);
			printf("Valor Convertido da bateria1 = %.2f\n\r", tension[1]);
			printf("Valor Convertido da bateria2 = %.2f\n\r", tension[2]);
			printf("Temperatura = %.2f\n\r", temperature);


			HAL_Delay(100);
		}
	#endif

	return 0;
}

extern "C"
{
	#include "usbd_cdc_if.h"

	#define USB_TIMEOUT 100

	//extern UART_HandleTypeDef huart2;

	int _write(int file, char *ptr, int len)
	{
		uint32_t start = HAL_GetTick();
		uint8_t status;
		do
		{
			//HAL_UART_Transmit(UART_SERIAL, (uint8_t*)ptr, len, MAX_SERIAL_TIMEOUT);
			status = CDC_Transmit_FS((uint8_t*) ptr, len);
			if(status == USBD_OK) return len;

		} while((status == USBD_BUSY) && ((HAL_GetTick() - start) < USB_TIMEOUT));

		return -1;
	}
}

