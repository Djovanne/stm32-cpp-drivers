################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../application/app_main/App_main.cpp 

OBJS += \
./application/app_main/App_main.o 

CPP_DEPS += \
./application/app_main/App_main.d 


# Each subdirectory must supply rules for building sources it contributes
application/app_main/%.o application/app_main/%.su application/app_main/%.cyclo: ../application/app_main/%.cpp application/app_main/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/giova/STM32CubeIDE/workspace_1.19.0/mag_sensor/application/LSM303AGR" -I"C:/Users/giova/STM32CubeIDE/workspace_1.19.0/mag_sensor/application/app_main" -I"C:/Users/giova/STM32CubeIDE/workspace_1.19.0/mag_sensor/application/Utility" -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-application-2f-app_main

clean-application-2f-app_main:
	-$(RM) ./application/app_main/App_main.cyclo ./application/app_main/App_main.d ./application/app_main/App_main.o ./application/app_main/App_main.su

.PHONY: clean-application-2f-app_main

