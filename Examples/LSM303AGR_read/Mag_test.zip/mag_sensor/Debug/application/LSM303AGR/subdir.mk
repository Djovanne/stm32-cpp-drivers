################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../application/LSM303AGR/Magnetometer.cpp 

OBJS += \
./application/LSM303AGR/Magnetometer.o 

CPP_DEPS += \
./application/LSM303AGR/Magnetometer.d 


# Each subdirectory must supply rules for building sources it contributes
application/LSM303AGR/%.o application/LSM303AGR/%.su application/LSM303AGR/%.cyclo: ../application/LSM303AGR/%.cpp application/LSM303AGR/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/giova/STM32CubeIDE/workspace_1.19.0/mag_sensor/application/LSM303AGR" -I"C:/Users/giova/STM32CubeIDE/workspace_1.19.0/mag_sensor/application/app_main" -I"C:/Users/giova/STM32CubeIDE/workspace_1.19.0/mag_sensor/application/Utility" -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-application-2f-LSM303AGR

clean-application-2f-LSM303AGR:
	-$(RM) ./application/LSM303AGR/Magnetometer.cyclo ./application/LSM303AGR/Magnetometer.d ./application/LSM303AGR/Magnetometer.o ./application/LSM303AGR/Magnetometer.su

.PHONY: clean-application-2f-LSM303AGR

