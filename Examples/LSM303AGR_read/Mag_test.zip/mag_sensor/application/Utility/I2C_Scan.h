/*
 * I2C_Scan.h
 *
 *  Created on: Aug 31, 2025
 *      Author: giova
 */

#ifndef UTILITY_I2C_SCAN_H_
#define UTILITY_I2C_SCAN_H_

#include "main.h"

void I2C_SCAN(I2C_HandleTypeDef *hi2c1)
{
	uint8_t address_found[10];
    uint8_t devices_found = 0;

    for (uint8_t address = 0x03; address < 0x78; address++)
    {
        if (HAL_I2C_IsDeviceReady(hi2c1, address << 1, 1, 10) == HAL_OK)
        {
        	address_found[devices_found] = address << 1;
            devices_found++;
        }
    }

    if (devices_found == 0)
    	printf("Nenhum dispositivo encontrado.");

    else
    {
    	printf("Foi encontrado %u dispositivo(s) nesse barramento, com endereco(s):\n",devices_found);
    	for(int i = 0; i < devices_found; i++ )
    		printf("0x%02X\n",address_found[i]);
    }
}

#endif /* UTILITY_I2C_SCAN_H_ */
