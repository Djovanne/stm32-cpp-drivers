/*
 * Serial_print.h
 *
 *  Created on: Aug 31, 2025
 *      Author: giova
 *
 *      Para escrita do "printf" em um terminal serial (como Termite ou Tera Term)
 */

#ifndef UTILITY_SERIAL_PRINT_H_
#define UTILITY_SERIAL_PRINT_H_

#include "main.h"
#include <stdio.h>

extern UART_HandleTypeDef huart2; //pino Uart que será redirecionado

#ifdef __cplusplus
extern "C" {
#endif

#define PUTCHAR_PROTOTYPE int __io_putchar(int ch) // para printf no terminal

PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART1 and Loop until the end of transmission */
  HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 0xFFFF);

  return ch;
}

#ifdef __cplusplus
}
#endif

#endif /* UTILITY_SERIAL_PRINT_H_ */
