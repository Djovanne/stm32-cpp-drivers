/*
 * App_main.cpp
 *
 *  Created on: Aug 31, 2025
 *      Author: giova
 */

///// Includes /////

#include "App_main.h"
#include "main.h"
#include "Magnetometer.h"
#include "I2C_Scan.h"
#include "Serial_print.h"

//// Barramentos Externos ////

extern I2C_HandleTypeDef hi2c1;
extern UART_HandleTypeDef huart2;

//// Sensores ////

Magnetometer magnetometer;

///// Variáveis Globais /////

float temperature;
float magField[3];
float accField[3];
float module_magField;
int16_t offset[] = {0,0,0};
float maxmim[3][2];

///// Configurações iniciais /////

void setup()
{
	I2C_SCAN(&hi2c1); //Faz o Scaneamento dos dispositivos conectados no barramento

	magnetometer.init(&hi2c1);
	magnetometer.set_offset(offset);
	magnetometer.read_offset(offset);

}

void loop()
{
	HAL_Delay(100); //ODR está em 10 Hz
//
	magnetometer.temperature_data(&temperature);
	magnetometer.magnetic_data(magField, &module_magField);
	magnetometer.acceleration_data(accField);


}
