/*
 * App_main.cpp
 *
 *  Created on: Jan 21, 2026
 *      Author: giova
 */

#include "App_main.hh"
#include "GlobalDefines.h"
#include "DigitalOut.hh"
#include "SDCard.hh"
#include <stdio.h>

int app_main()
{
	DigitalOut led(LED);
	SDCard sd(SDPath);

	const char filename[] = "arquivo.txt";

	HAL_Delay(500);

	while(!sd.mount())
	{
		debugPrint("\n\rEsperando encaixar o SD card...\n\r");
		led.toggle();
		HAL_Delay(200);

	}

	debugPrint("SD Card montado com sucesso!\n\r");
	debugPrint("Espaço livre %lu\n\r", sd.getFreeSpaceKB());

	sd.printLog(filename, "Tick_ms,Dado_A,Dado_B\n");

	uint32_t dadoSimulado = 0;
	uint32_t delay = HAL_GetTick();

	while(1)
	{
		if((HAL_GetTick() - delay) > 1000)
		{
			bool status = sd.printLog(filename, "%lu,%lu,%f\n",HAL_GetTick(), dadoSimulado++,3);
			if(!status)
				debugPrint("Erro ao gravar no SD!\n\r");

			delay = HAL_GetTick();

			led = 1;
			HAL_Delay(100);
		}
		led = 0;
	}

	return 0;
}
