/*
 * GlobalDefines.h
 *
 *  Created on: Jan 15, 2026
 *      Author: giova
 */
#include "main.h"

// Definição Struct PinName para ser mais natural na alocação de pinos GPIO

#ifndef PINNAME
#define PINNAME
struct PinName
{
	GPIO_TypeDef* port;
	uint16_t pin;
};
#endif

//barramendos

#define LED   (PinName){GPIOB, GPIO_PIN_2} //PB2

#define DEBUG_MESSAGES
#ifdef DEBUG_MESSAGES
  #define debugPrint(fmt, ...) printf(fmt, ##__VA_ARGS__)
#else
  #define debugPrint(fmt, ...)
#endif
