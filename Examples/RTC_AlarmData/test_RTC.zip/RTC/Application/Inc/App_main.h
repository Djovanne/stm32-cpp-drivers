/*
 * Appmain.h
 *
 *  Created on: Jan 22, 2026
 *      Author: giova
 */

#ifndef INC_APP_MAIN_H_
#define INC_APP_MAIN_H_

#ifdef __cplusplus
extern "C" {
#endif

int app_main();

#ifdef __cplusplus
}
#endif


#endif /* INC_APP_MAIN_H_ */
