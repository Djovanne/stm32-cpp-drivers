/*
 * Appmain.cpp
 *
 *  Created on: Jan 22, 2026
 *      Author: giova
 */

#include "App_main.h"
#include "main.h"
#include "stdio.h"
#include "usbd_cdc_if.h"

extern RTC_HandleTypeDef hrtc;
volatile bool flag = false;

#define TimeOut_freq 100

int app_main()
{
	RTC_DateTypeDef  date  = {0}; //variável de data
	RTC_TimeTypeDef  time  = {0}; //variavel de tempo
	RTC_AlarmTypeDef alarm = {0}; //variavel do alarme

	//Hora de início
	time.Hours   = 23;
	time.Minutes = 59;
	time.Seconds = 30;

	//Data do início
	date.Date = 17;
	date.WeekDay = RTC_WEEKDAY_THURSDAY;
	date.Month = 6;
	date.Year = 26;

	//Configuração do alarme
	alarm.AlarmTime.Hours = 00;
	alarm.AlarmTime.Minutes = 00;
	alarm.AlarmTime.Seconds = 00;
	alarm.AlarmSubSecondMask = RTC_ALARMSUBSECONDMASK_ALL; //mascara que ele faz para selecionar em cima de qual dado é o alarme
	alarm.AlarmDateWeekDaySel = RTC_ALARMDATEWEEKDAYSEL_DATE; //diz que é um dia do mês, e não da semana
	alarm.AlarmDateWeekDay = 18;

	alarm.AlarmMask = RTC_ALARMMASK_NONE;
	alarm.Alarm = RTC_ALARM_A;

	HAL_RTC_DeactivateAlarm(&hrtc, RTC_ALARM_A);

	HAL_Delay(1000);
	printf("\n\rIniciado o teste do RTC!\n\r");

	uint32_t delay = HAL_GetTick();
	uint8_t uls = 0;

	if(HAL_RTC_SetTime(&hrtc, &time, RTC_FORMAT_BIN) != HAL_OK)   Error_Handler();
	if(HAL_RTC_SetDate(&hrtc, &date, RTC_FORMAT_BIN) != HAL_OK)   Error_Handler();
	if(HAL_RTC_SetAlarm_IT(&hrtc, &alarm, RTC_FORMAT_BIN)) Error_Handler();

	while(1)
	{
		if(((HAL_GetTick() - delay) > TimeOut_freq) && !flag)
		{
			HAL_RTC_GetTime(&hrtc, &time, RTC_FORMAT_BIN);
			HAL_RTC_GetDate(&hrtc, &date, RTC_FORMAT_BIN);
			printf("\n\r ano %d mes: %d dia mês: %d dia da semana: %d \n\r", date.Year, date.Month, date.Date, date.WeekDay);
			printf("Horas %d Minutos: %d Segundos: %d\n\r", time.Hours, time.Minutes, time.Seconds);



			delay = HAL_GetTick();
		}

		if((time.Seconds != uls) && !flag)
		{
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);
			HAL_Delay(10);
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
		}

		if(flag)
		{
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);
		}
		uls = time.Seconds;
	}

	return 0;
}

void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc)
{
	flag = true;
}

extern "C"
{

#define USB_TIMEOUT 10

//extern UART_HandleTypeDef huart2;

int _write(int file, char *ptr, int len)
{
	uint32_t start = HAL_GetTick();
	uint8_t status;
	do
	{
		//HAL_UART_Transmit(UART_SERIAL, (uint8_t*)ptr, len, MAX_SERIAL_TIMEOUT);
		status = CDC_Transmit_FS((uint8_t*) ptr, len);
		if(status == USBD_OK) return len;

	} while((status == USBD_BUSY) && ((HAL_GetTick() - start) < USB_TIMEOUT));

	return -1;
}

}
