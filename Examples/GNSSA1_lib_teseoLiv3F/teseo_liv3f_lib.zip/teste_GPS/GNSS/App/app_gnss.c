/**
  ******************************************************************************
  * @file    app_gnss.c
  * @author  SRA Application Team
  * @brief   GNSS initialization and applicative code
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "app_gnss.h"

/* Includes ------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "gnss1a1_conf.h"
#include "teseo_liv3f_conf.h"

#include "gnss1a1_gnss.h"
#include "gnss_data.h"
#include "custom.h"
#include "gnss_feature_cfg_data.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private defines -----------------------------------------------------------*/

/* Global variables ----------------------------------------------------------*/

/* Instance of GNSS Handler */

/* Private variables ---------------------------------------------------------*/
static GNSSParser_Data_t GNSSParser_Data;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
static void MX_SimOSGetPos_Process(void);

//#if (CONFIG_USE_FEATURE == 1)
static void AppCfgMsgList(uint32_t lowMask, uint32_t highMask);
static void AppGeofenceCfg(char *command);
static void AppEnFeature(char *command);
//#endif /* CONFIG_USE_FEATURE */

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

void MX_GNSS_Init(void)
{
  /* USER CODE BEGIN GNSS_Init_PreTreatment */

  /* USER CODE END GNSS_Init_PreTreatment */

  /* Initialize the peripherals and the teseo device */
  if (BSP_COM_Init(COM1) != BSP_ERROR_NONE)
  {
    Error_Handler();
  }

  PRINT_DBG("Booting...\r\n");

  /* USER CODE BEGIN GNSS_Init_PostTreatment */

  /* USER CODE END GNSS_Init_PostTreatment */
}

void MX_GNSS_Process(void)
{
  /* USER CODE BEGIN GNSS_Process_PreTreatment */

  /* USER CODE END GNSS_Process_PreTreatment */
  MX_SimOSGetPos_Process();

  /* USER CODE BEGIN GNSS_Process_PostTreatment */

  /* USER CODE END GNSS_Process_PostTreatment */
}

/* TeseoConsumerTask function */
static void MX_SimOSGetPos_Process(void)
{
  GNSSParser_Status_t status, check;
  const GNSS1A1_GNSS_Msg_t *gnssMsg;
//#if (CONFIG_USE_FEATURE == 1)
  static uint8_t config_done = 0;
//#endif /* CONFIG_USE_FEATURE */

  GNSS1A1_GNSS_Init(GNSS1A1_TESEO_LIV3F);

  BSP_COM_Init(COM1);
  BSP_COM_SelectLogPort(COM1);

  printf("Inicializacao do GPS Concluida!\r\n");

  GNSS_PARSER_Init(&GNSSParser_Data);

  for (;;)
  {

  //GNSS1A1_GNSS_BackgroundProcess(GNSS1A1_TESEO_LIV3F);

//#if (USE_I2C == 1)
    GNSS1A1_GNSS_BackgroundProcess(GNSS1A1_TESEO_LIV3F);
//#endif /* USE_I2C */

//#if (CONFIG_USE_FEATURE == 1)
    /* See CDB-ID 201 - This LOW_BITS Mask enables the following messages:
     * 0x1 $GPGNS Message
     * 0x2 $GPGGA Message
     * 0x4 $GPGSA Message
     * 0x8 $GPGST Message
     * 0x40 $GPRMC Message
     * 0x80000 $GPGSV Message
     * 0x100000 $GPGLL Message
     */
    if (!config_done)
    {
      uint32_t lowMask = 0x18004F;
      uint32_t highMask = GEOFENCE;
      PRINT_OUT("\n\rConfigure Message List\n\r");
      AppCfgMsgList(lowMask, highMask);
      HAL_Delay(1000);  /* Allows to catch the reply from Teseo */

      PRINT_OUT("\n\rEnable Geofence\r");
      AppEnFeature("GEOFENCE,1");
      HAL_Delay(500);  /* Allows to catch the reply from Teseo */

      PRINT_OUT("\n\rConfigure Geofence Circle\n\r");
      AppGeofenceCfg("Geofence-Lecce");

      config_done = 1;
    }
//#endif /* CONFIG_USE_FEATURE */

    gnssMsg = GNSS1A1_GNSS_GetMessage(GNSS1A1_TESEO_LIV3F);

    if (gnssMsg == NULL)
    {
      continue;
    }

    check = GNSS_PARSER_CheckSanity((uint8_t *)gnssMsg->buf, gnssMsg->len);

    if (check != GNSS_PARSER_ERROR)
    {
      for (uint8_t m = 0; m < NMEA_MSGS_NUM; m++)
      {
        status = GNSS_PARSER_ParseMsg(&GNSSParser_Data, (eNMEAMsg)m, (uint8_t *)gnssMsg->buf);

        if ((status != GNSS_PARSER_ERROR) && ((eNMEAMsg)m == GPGGA))
        {
          GNSS_DATA_GetValidInfo(&GNSSParser_Data);
        }

        if ((status != GNSS_PARSER_ERROR) && ((eNMEAMsg)m == GPRMC))
		{
        	GNSS_DATA_GetValidInfo(&GNSSParser_Data);

        	if(GNSSParser_Data.gprmc_data.status == 'A')
        	{
        		// Conversão das cordenadas
        		// ----------------- latitude DDMM.MMMMM------------------------
        		float lat_raw = GNSSParser_Data.gprmc_data.xyz.lat;
				int lat_deg = (int)(lat_raw / 100);
				float lat_dec = lat_deg + ((lat_raw - (lat_deg * 100)) / 60.0);
				if(GNSSParser_Data.gprmc_data.xyz.ns == 'S') lat_dec *= -1;
				// ------------------ longitude DDMM.MMMMM----------------------
				float lon_raw = GNSSParser_Data.gprmc_data.xyz.lon;
				int lon_deg = (int)(lon_raw / 100);
				float lon_dec = lon_deg + ((lon_raw - (lon_deg * 100)) / 60.0);
				if(GNSSParser_Data.gprmc_data.xyz.ew == 'W') lon_dec *= -1;


        		float vel_nos = GNSSParser_Data.gprmc_data.speed;
				float vel_kmh = vel_nos * 1.852f; // Conversão de nós para km/h

				printf("\r\n--- NAVEGACAO (RMC) ---\r\n");
				printf("UTC:       %02d:%02d:%02d\r\n",
					 GNSSParser_Data.gprmc_data.utc.hh,
					 GNSSParser_Data.gprmc_data.utc.mm,
					 GNSSParser_Data.gprmc_data.utc.ss);

				printf("COORD: %.7f, %.7f\r\n", lat_dec, lon_dec);

				/* VELOCIDADE EXTRAÍDA AQUI */
				printf("Velocid.:  %.2f km/h (%.2f kts)\r\n", vel_kmh, vel_nos);

				/* ALTITUDE (Vem da GPGGA processada acima) */
				printf("Altitude:  %.2f%c\r\n", GNSSParser_Data.gpgga_data.xyz.alt, GNSSParser_Data.gpgga_data.xyz.mis + 32U);

				printf("SATS : %d | HDOP: %.1f\r\n",
				                     GNSSParser_Data.gpgga_data.sats,
				                     GNSSParser_Data.gpgga_data.acc);

				printf("-----------------------\r\n");
			}
			else
			{
				printf("Aguardando sinal válido (Status V)...\r\n");
			}
		}
#if (CONFIG_USE_FEATURE == 1)
        if ((status != GNSS_PARSER_ERROR) && ((eNMEAMsg)m == PSTMGEOFENCE))
        {
          GNSS_DATA_GetGeofenceInfo(&GNSSParser_Data);
        }
        if ((status != GNSS_PARSER_ERROR) && ((eNMEAMsg)m == PSTMSGL))
        {
          GNSS_DATA_GetMsglistAck(&GNSSParser_Data);
        }
        if ((status != GNSS_PARSER_ERROR) && ((eNMEAMsg)m == PSTMSAVEPAR))
        {
          GNSS_DATA_GetGNSSAck(&GNSSParser_Data);
        }
#endif /* CONFIG_USE_FEATURE */
      }
    }

    GNSS1A1_GNSS_ReleaseMessage(GNSS1A1_TESEO_LIV3F, gnssMsg);
  }
}

//#if (CONFIG_USE_FEATURE == 1)
/* CfgMessageList */
static void AppCfgMsgList(uint32_t lowMask, uint32_t highMask)
{
  GNSS_DATA_CfgMessageList(lowMask, highMask);
}

static void AppEnFeature(char *command)
{
  if (strcmp(command, "GEOFENCE,1") == 0)
  {
    GNSS_DATA_EnableGeofence(1);
  }
  if (strcmp(command, "GEOFENCE,0") == 0)
  {
    GNSS_DATA_EnableGeofence(0);
  }
}

static void AppGeofenceCfg(char *command)
{
  if (strcmp(command, "Geofence-Lecce") == 0)
  {
    GNSS_DATA_ConfigGeofence(&Geofence_STLecce);
  }
  if (strcmp(command, "Geofence-Catania") == 0)
  {
    GNSS_DATA_ConfigGeofence(&Geofence_Catania);
  }
}
//#endif /* CONFIG_USE_FEATURE */

uint8_t GNSS_PRINT(char *pBuffer)
{
  if (HAL_UART_Transmit(&hcom_uart[COM1], (uint8_t *)pBuffer, (uint16_t)strlen((char *)pBuffer), 1000) != HAL_OK)
  {
    return 1;
  }
  fflush(stdout);

  return 0;
}

uint8_t GNSS_PUTC(char pChar)
{
  if (HAL_UART_Transmit(&hcom_uart[COM1], (uint8_t *)&pChar, 1, 1000) != HAL_OK)
  {
    return 1;
  }
  fflush(stdout);

  return 0;
}

