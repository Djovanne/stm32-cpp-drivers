################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
CYCLO_FILES := 
SIZE_OUTPUT := 
OBJDUMP_LIST := 
SU_FILES := 
EXECUTABLES := 
OBJS := 
MAP_FILES := 
S_DEPS := 
S_UPPER_DEPS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Core/Src \
Core/Startup \
Drivers/BSP/Components/teseo_liv3f \
Drivers/BSP/GNSS1A1 \
Drivers/BSP/custom \
Drivers/STM32G4xx_HAL_Driver/Src \
GNSS/App \
GNSS/Target \
Middlewares/ST/lib_gnss/LibGNSS/Src \
Middlewares/ST/lib_gnss/LibNMEA/Src \

