Application/USBSerial.o: ../Application/USBSerial.c
