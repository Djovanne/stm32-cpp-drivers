USB/Class/CompositeBuilder/Src/usbd_composite_builder.o: \
 ../USB/Class/CompositeBuilder/Src/usbd_composite_builder.c \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/CompositeBuilder/Inc/usbd_composite_builder.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_ioreq.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_def.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Target/usbd_conf.h \
 ../Core/Inc/main.h ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h \
 ../Core/Inc/stm32f4xx_hal_conf.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f411xe.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_usb.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd_ex.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_core.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_ioreq.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_ctlreq.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/MSC/Inc/usbd_msc.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/MSC/Inc/usbd_msc_bot.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_core.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/MSC/Inc/usbd_msc_scsi.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_def.h \
 C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/CDC/Inc/usbd_cdc.h
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/CompositeBuilder/Inc/usbd_composite_builder.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_ioreq.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_def.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Target/usbd_conf.h:
../Core/Inc/main.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h:
../Core/Inc/stm32f4xx_hal_conf.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f411xe.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_usb.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd_ex.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_core.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_ioreq.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_ctlreq.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/MSC/Inc/usbd_msc.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/MSC/Inc/usbd_msc_bot.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_core.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/MSC/Inc/usbd_msc_scsi.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Core/Inc/usbd_def.h:
C:/Users/giova/OneDrive/Documentos/STM32/USB_COMPO_test/USB/Class/CDC/Inc/usbd_cdc.h:
