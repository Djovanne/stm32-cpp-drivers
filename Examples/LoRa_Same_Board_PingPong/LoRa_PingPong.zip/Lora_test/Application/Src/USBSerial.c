/*
 * USBSerial.c
 *
 *  Created on: Jan 15, 2026
 *      Author: giova
 */

#include <stdio.h>
#include "main.h"
#include "usbd_cdc_if.h"

#define USB_TIMEOUT 100

//extern UART_HandleTypeDef huart2;

int _write(int file, char *ptr, int len)
{
	uint32_t start = HAL_GetTick();
	uint8_t status;
	do
	{
		//HAL_UART_Transmit(UART_SERIAL, (uint8_t*)ptr, len, MAX_SERIAL_TIMEOUT);
		status = CDC_Transmit_FS((uint8_t*) ptr, len);
		if(status == USBD_OK) return len;

	} while((status == USBD_BUSY) && ((HAL_GetTick() - start) < USB_TIMEOUT));

	return -1;
}
