/*
 * LORA.cpp
 *
 *  Created on: Sep 8, 2025
 *      Author: giova
 */

// includes das bribriotecas

#include "LORA.hh"
#include <string.h>
#include <stdio.h>

LORA::LORA(UART_HandleTypeDef* huart, PinName aux, PinName m0, PinName m1)
{
	this->_huart = huart;
	this->_aux   = aux;
	this->_m0    = m0;
	this->_m1    = m1;

	this->dataAvailableFlag = false;
	this->txBusy = false;
	this->lastPacketSize     = 0;
}

LORA::~LORA() {}

//////////////////////////////////// habilita o DMA ////////////////////////////

HAL_StatusTypeDef LORA::enableReception()
{
	HAL_UART_AbortReceive(this->_huart);
	memset(this->rxBuffer, 0, E32_MAX_RX_BUFFER);
	HAL_StatusTypeDef status = HAL_UARTEx_ReceiveToIdle_DMA(this->_huart, this->rxBuffer, E32_MAX_RX_BUFFER);
	HAL_Delay(1);
	return status;
}

//////////////////////////////////// Desabilita o DMA ////////////////////////////

HAL_StatusTypeDef LORA::disableReception()
{
	HAL_StatusTypeDef status = HAL_UART_DMAStop(_huart);
	HAL_UART_AbortReceive(_huart);
	__HAL_UART_FLUSH_DRREGISTER(_huart);
	return status;
}

//////////////////////////////////// método chamado pela interrupção ////////////////////////////

void LORA::handleInterrupt(uint16_t Size)
{
    // "Size" é passado automaticamente pela HAL informando quantos bytes chegaram
    this->lastPacketSize = Size;
    this->dataAvailableFlag = true;
}

//////////////////////////////////// método flag se recebeu dado ////////////////////////////

const bool LORA::isDataAvailable()
{
    return this->dataAvailableFlag;
}

//////////////////////////////////// resgata o dado do buffer  ////////////////////////////

uint16_t LORA::readData(uint8_t* userBuffer, uint16_t maxSize)
{
    if (!dataAvailableFlag) return 0;

    // Ternário pergunta se o tamanho da mensagem ou do buffer do usuário é maior
    uint16_t copySize = (this->lastPacketSize > maxSize) ? maxSize : this->lastPacketSize;
    memcpy(userBuffer, this->rxBuffer, copySize);
    dataAvailableFlag = false;

    enableReception();
    return copySize;
}

//////////////////////////////////// inicializa o LORA ////////////////////////////

HAL_StatusTypeDef LORA::init ()
{
	debugPrint("LORA E32 Init...\n\r");

	if(waitForAuxHigh(1000) != HAL_OK) {
		printf("TIMEOUT: Modulo E32 nao respondeu (AUX Low).\n\r");
		return HAL_TIMEOUT;
	}

	LoraConfig_s config;

	// Configurações Básicas
	config.head = LORA_SAVE_PERMANENT; // 0xC0
	config.addh = 0x00;
	config.addl = 0x00;
	config.chan = 23; // 433MHz (410 + 23)

	// Configuração SPED (Velocidades)
	config.sped.uartParity   = LORA_PARITY_8N1;
	config.sped.uartBaudRate = LORA_BAUD_9600;
	config.sped.airDataRate  = LORA_AIR_2_4K;

	// Configuração OPTION (Opções Avançadas)
	config.option.fixedTransmission = LORA_MODE_TRANSPARENT;
	config.option.ioDriveMode       = LORA_IO_PUSH_PULL;
	config.option.wakeupTime        = LORA_WAKEUP_250MS;
	config.option.fecSwitch         = LORA_FEC_ON;
	config.option.transmissionPower = LORA_POWER_30DBM;

	if(setConfig(config) != HAL_OK)
	{
		printf("ERRO: Falha ao aplicar configuracao inicial.\n\r");
		return HAL_ERROR;
	}

	enableReception();

	return HAL_OK;

}

//////////////////////////////////// Pergunta se o envio acabou ////////////////////////////

bool LORA::isTxReady()
{
    return !this->txBusy;
}

//////////////////////////////////// método que a hal reinicia a flag ////////////////////////////

void LORA::handleTxInterrupt()
{
    this->txBusy = false;
}

//////////////////////////////////// envia uma mensagem a um canal específico ////////////////////////////

HAL_StatusTypeDef LORA::sendMessage(uint16_t address, uint8_t channel, uint8_t* data, uint8_t length) 
{
	if (this->txBusy) return HAL_BUSY; // Retorna ocupado se tentar enviar em cima de outro

	if ((length + 3) > E32_MAX_TX_BUFFER) return HAL_ERROR; // 3 bytes de cabeçalho + dados não podem estourar o buffer

	if(waitForAuxHigh(1000) != HAL_OK) return HAL_BUSY; // checa se não está ocupado

    if (setMode(MODE_NORMAL) != HAL_OK) return HAL_ERROR; // configura para transmissão normal

	// ----- montagem do quadro de dados da mensagem ----- //

    this->txBuffer[0] = (uint8_t)(address >> 8);
    this->txBuffer[1] = (uint8_t)(address & 0xFF);
    this->txBuffer[2] = channel;
    memcpy(&(this->txBuffer[3]), data, length);

    this->txBusy = true;

    if (HAL_UART_Transmit_DMA(_huart, this->txBuffer, length + 3) != HAL_OK)
    {
		this->txBusy = false;
		return HAL_ERROR;
	}

    return HAL_OK;
}

//////////////////////////////////// envia mensagem a todos os canais ////////////////////////////

HAL_StatusTypeDef LORA::sendBroadcastMessage(uint8_t channel, uint8_t* data, uint8_t length) 
{
    // O endereço de broadcast é 0xFFFF
    return sendMessage(0xFFFF, channel, data, length);
}

//////////////////////////////////// método para colocar uma configuração ////////////////////////////

HAL_StatusTypeDef LORA::setConfig(LoraConfig_s config) 
{
	disableReception();

	config.head = 0xC0; //para configuração permanente

    uint8_t config_bytes[6];
    memcpy(config_bytes, &config, 6);

	//entra no modo de configuração do módulo
    if (setMode(MODE_SLEEP_CONFIG) != HAL_OK) 
	{
    	debugPrint("Falha ao entrar no modo de configuracao.\n\r");
        setMode(MODE_NORMAL);
        return HAL_ERROR;
    }

    HAL_Delay(10);

	// envia o comando de configuraçãp
    if (HAL_UART_Transmit(_huart, config_bytes, 6, E32_TX_TIMEOUT) != HAL_OK)
	{
    	debugPrint("Falha ao enviar comando de configuracao.\n\r");
        setMode(MODE_NORMAL);
        return HAL_ERROR;
    }
    uint8_t response[6] = {0};

    if (HAL_UART_Receive(_huart, response, 6, E32_TX_TIMEOUT) != HAL_OK)
	{
    	debugPrint("Timeout: O modulo nao respondeu a confirmacao.\n\r");
		setMode(MODE_NORMAL);
		return HAL_TIMEOUT;
	}

	// Compara os dois arrays de memória, byte a byte, para ver se são iguais (igualmente gaymer esse método)
    if(memcmp(config_bytes, response, 6) != 0)
	{
    	debugPrint("Erro: O modulo retornou uma config diferente da enviada!\n\r");
    	debugPrint("Enviado: %02X, Recebido: %02X\n\r", config_bytes[3], response[3]); // Exemplo debug SPED
		setMode(MODE_NORMAL);
		return HAL_ERROR;
	}

    debugPrint("Configuracao salva com sucesso!\n\r");
    enableReception();
    return setMode(MODE_NORMAL);
}

//////////////////////////////////// método para ler uma configuração ////////////////////////////

HAL_StatusTypeDef LORA::readConfig(LoraConfig_s* config) 
{
	// para o DMA
	disableReception();

	// coloca no modo configuração
    if (setMode(MODE_SLEEP_CONFIG) != HAL_OK)
	{
    	setMode(MODE_NORMAL);
    	return HAL_ERROR;
	}

    HAL_Delay(10);

	// envia tres comandos de leitura para ler as configurações (conforme ditos no manuar, estranho)
    uint8_t cmd[] = {
    		E32_CMD_READ_CONFIG,
			E32_CMD_READ_CONFIG,
			E32_CMD_READ_CONFIG
    };

    if(HAL_UART_Transmit(_huart, cmd, sizeof(cmd), E32_TX_TIMEOUT) != HAL_OK)
    {
    	debugPrint("Erro ao enviar comando de leitura.\n\r");
		setMode(MODE_NORMAL);
		return HAL_ERROR;
    }
    // recebe os dados de configuração
    uint8_t response[6] = {0};

    if (HAL_UART_Receive(_huart, response, sizeof(response), E32_TX_TIMEOUT) != HAL_OK)
    {
    	debugPrint("Timeout: Falha ao ler config do modulo.\n\r");
		setMode(MODE_NORMAL);
		return HAL_TIMEOUT;
    }
    // copia as configurações de "response" para config, e printa as configurações depois
    memcpy(config, response, 6);
    printConfig(*config);

    enableReception();

    return setMode(MODE_NORMAL);
}

//////////////////////////////////// método para reiniciar o modulo ////////////////////////////

HAL_StatusTypeDef LORA::resetModule() 
{
	disableReception();

    if (setMode(MODE_SLEEP_CONFIG) != HAL_OK)
    {
    	setMode(MODE_NORMAL);
    	return HAL_ERROR;
    }
    
    HAL_Delay(10);

	// Faz o reset do módulo
    uint8_t cmd[] = {
    		E32_CMD_RESET,
			E32_CMD_RESET,
			E32_CMD_RESET
    };

    HAL_UART_Transmit(_huart, cmd, sizeof(cmd), E32_TX_TIMEOUT);
    
    enableReception();

    return waitForAuxHigh(E32_AUX_TIMEOUT); // Aguarda o módulo estar pronto
}

//////////////////////////////////// método para leitura do LOG ////////////////////////////

void LORA::printConfig(LoraConfig_s& config) 
{
	debugPrint("--- Lora E32 Config ---\n\r");
	debugPrint("HEAD: 0x%02X\n\r", config.head);
	debugPrint("ADDR: %d (0x%02X%02X)\n\r", (config.addh << 8) | config.addl, config.addh, config.addl);
	debugPrint("CHAN: %d (%.1f MHz)\n\r", config.chan, 862.0 + config.chan);
	debugPrint("UART Parity: %d\n\r", config.sped.uartParity);
	debugPrint("UART Baud: %d\n\r", config.sped.uartBaudRate);
	debugPrint("Air Data Rate: %d\n\r", config.sped.airDataRate);
	debugPrint("Fixed Tx: %d\n\r", config.option.fixedTransmission);
	debugPrint("FEC: %d\n\r", config.option.fecSwitch);
	debugPrint("Power: %d\n\r", config.option.transmissionPower);
    debugPrint("-----------------------\n\r");
}

//////////////////////////////////// método para colocar o modo ////////////////////////////

HAL_StatusTypeDef LORA::setMode(LoraMode mode) 
{

	//Configura o modo do módulo conforme a entrada
    switch (mode) {
        case MODE_NORMAL:
            HAL_GPIO_WritePin(_m0.gate, _m0.pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(_m1.gate, _m1.pin, GPIO_PIN_RESET);
            break;
        case MODE_WAKE_UP:
            HAL_GPIO_WritePin(_m0.gate, _m0.pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(_m1.gate, _m1.pin, GPIO_PIN_RESET);
            break;
        case MODE_POWER_SAVING:
            HAL_GPIO_WritePin(_m0.gate, _m0.pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(_m1.gate, _m1.pin, GPIO_PIN_SET);
            break;
        case MODE_SLEEP_CONFIG:
            HAL_GPIO_WritePin(_m0.gate, _m0.pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(_m1.gate, _m1.pin, GPIO_PIN_SET);
            break;
    }

    // Checa o termino da operação
    return waitForAuxHigh(E32_AUX_TIMEOUT);
}

//////////////////////////////////// método de aguardo do aux ////////////////////////////

HAL_StatusTypeDef LORA::waitForAuxHigh(uint32_t timeout) 
{
    uint32_t start_tick = HAL_GetTick();
	// verifica se o sinal no pino auxiliar está baixo
    while (HAL_GPIO_ReadPin(_aux.gate, _aux.pin) == GPIO_PIN_RESET)
	{
		// retorna erro caso não abaixe a tempo
        if ((HAL_GetTick() - start_tick) > timeout)
		{
            return HAL_TIMEOUT;
        }
    }
    return HAL_OK;
}
