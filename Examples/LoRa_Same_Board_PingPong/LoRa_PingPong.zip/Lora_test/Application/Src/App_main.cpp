/*
 * App_main.cpp
 *
 *  Created on: Aug 31, 2025
 *      Author: giova
 */

#include "GlobalLibraries.h"
#include <string.h>

static LORA* pLora1 = nullptr;
static LORA* pLora2 = nullptr;

uint32_t lastSendTime = 0;
const uint32_t SEND_INTERVAL = 2000;

void App_main()
{

	static LORA lora1(LORA1_UART, LORA1_AUX, LORA1_M0, LORA1_M1);
	static LORA lora2(LORA2_UART, LORA2_AUX, LORA2_M0, LORA2_M1);

	pLora1 = &lora1;
	pLora2 = &lora2;

	HAL_Delay(500);

	debugPrint("--- Inicio do Teste LORA DMA Duplo ---\n\r");

	if (lora1.init() != HAL_OK) debugPrint("Erro Init Lora 1\n\r");
	if (lora2.init() != HAL_OK) debugPrint("Erro Init Lora 2\n\r");

	HAL_Delay(100);
	while(1)
	{
		// --- LÓGICA DE ENVIO (LORA 1 manda PING a cada 2s) ---
		if (HAL_GetTick() - lastSendTime > SEND_INTERVAL)
		{
			const char* msg = "PING LORA1";
			// Envia para o endereço 0x0000 no canal 23 (config padrão)
			// Nota: Se estiver em modo Transparente, o endereço é ignorado mas enviado como dado.
			debugPrint("[TX] Lora 1 enviando: %s\n\r", msg);
			lora1.sendMessage(0x0000, 23, (uint8_t*)msg, strlen(msg));

			lastSendTime = HAL_GetTick();
		}

		// --- LÓGICA DE RECEPÇÃO LORA 2 (Recebe PING, responde PONG) ---
		if (lora2.isDataAvailable())
		{
			uint8_t buffer[100] = {0};
			uint16_t len = lora2.readData(buffer, sizeof(buffer)-1); // -1 para sobrar pro \0
			buffer[len] = '\0'; // Garante string válida para printf

			debugPrint("[RX] Lora 2 recebeu (%d bytes): %s\n\r", len, buffer);

			// Verifica se é um PING para responder
			// Nota1: strstr procura a substring, caso venha bytes de endereço junto
			// Nota2: é deslocado 3 casas a frente em decorência da configuralçao padrão ter endereço fixo (00, que tem terminação \0 de final de string)
			if (((len > 3) && (strstr((char*)&buffer[3], "PING"))) != false)
			{
				debugPrint("   -> Lora 2 respondendo PONG...\n\r");
				const char* resposta = "PONG LORA2";
				lora2.sendMessage(0x0000, 23, (uint8_t*)resposta, strlen(resposta));
			}
		}

		// --- LÓGICA DE RECEPÇÃO LORA 1 (Recebe PONG) ---
		if (lora1.isDataAvailable())
		{
			uint8_t buffer[100] = {0};
			uint16_t len = lora1.readData(buffer, sizeof(buffer)-1);
			buffer[len] = '\0';

			debugPrint("[RX] Lora 1 recebeu resposta: %s\n\r", &buffer[3]);
		}
	}
}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if (huart->Instance == LORA1_UART->Instance) {
    	pLora1->handleInterrupt(Size);
    }
    if (huart->Instance == LORA2_UART->Instance) {
    	pLora2->handleInterrupt(Size);
    }
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    // Verifica se foi a UART do LoRa que terminou de enviar
    if (huart->Instance == LORA1_UART->Instance) {
    	pLora1->handleTxInterrupt();
    }
    if (huart->Instance == LORA2_UART->Instance) {
    	pLora2->handleTxInterrupt();
    }
}
