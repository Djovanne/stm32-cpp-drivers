/*
 * GlobalDefines.h
 *
 *  Created on: Jan 15, 2026
 *      Author: giova
 */
#include "main.h"

// Definição Struct PinName para ser mais natural na alocação de pinos GPIO

#ifndef PINNAME
#define PINNAME
struct PinName
{
	GPIO_TypeDef* gate;
	uint16_t pin;
};
#endif

//barramendos

#ifndef EXTERN
#define EXTERN

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;

#endif
// LORA1 Interface

#define LORA1_UART (&huart1)
#define LORA1_RX   (PinName){GPIOA, GPIO_PIN_10} //PA10
#define LORA1_TX   (PinName){GPIOA, GPIO_PIN_15} //PA15
#define LORA1_M0   (PinName){GPIOB, GPIO_PIN_14}  //PB1
#define LORA1_M1   (PinName){GPIOB, GPIO_PIN_15}  //PB0
#define LORA1_AUX  (PinName){GPIOA, GPIO_PIN_8}  //PA7

// LORA2 Interface

#define LORA2_UART (&huart2)
#define LORA2_RX   (PinName){GPIOA, GPIO_PIN_3}  //PA3
#define LORA2_TX   (PinName){GPIOA, GPIO_PIN_2}  //PA2
#define LORA2_M0   (PinName){GPIOA, GPIO_PIN_5}  //PA1
#define LORA2_M1   (PinName){GPIOA, GPIO_PIN_4}  //PC
#define LORA2_AUX  (PinName){GPIOA, GPIO_PIN_1}  //PC13

// User Interface

#define LED 	   (PinName){GPIOB, GPIO_PIN_0} //PB0
#define BUZZER 	   (PinName){GPIOB, GPIO_PIN_0} //PB0

#define DEBUG_MESSAGES
#ifdef DEBUG_MESSAGES
  #define debugPrint(fmt, ...) printf(fmt, ##__VA_ARGS__)
#else
  #define debugPrint(fmt, ...)
#endif
