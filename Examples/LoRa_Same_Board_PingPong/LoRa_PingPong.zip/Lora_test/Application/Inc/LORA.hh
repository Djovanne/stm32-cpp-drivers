/*
 * LORA.h
 *
 *  Created on: Sep 8, 2025
 *      Author: giova
 * 
 * IMplementação do Módulo LORA - E32 900T20D no STM32CuveIDE
 * 
 * Para Usa-la, Ative a Interrupção e o DMA do RX e TX no MX
 * também chame as respetivas funções de interrupção na usa main, como por exemplo:
 *
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if (huart->Instance == LORA1_UART->Instance) {
    	pLora1->handleInterrupt(Size);
    }
    if (huart->Instance == LORA2_UART->Instance) {
    	pLora2->handleInterrupt(Size);
    }
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    // Verifica se foi a UART do LoRa que terminou de enviar
    if (huart->Instance == LORA1_UART->Instance) {
    	pLora1->handleTxInterrupt();
    }
    if (huart->Instance == LORA2_UART->Instance) {
    	pLora2->handleTxInterrupt();
    }
}

 * A Primeira é a interrupção para o caso de chegar algum dado no RX, em que retorna
 * o barramento em questão (huart), e quantos bytes foram recebidos.
 *
 * A segunda é para a transmissão dos dados em DMA também, liberando o controlador
 * para fazer outras coisas.
 */

// Canal DMA do LORA

#ifndef LORA_E32_LORA_H_
#define LORA_E32_LORA_H_

// includes //

#include "main.h"
#include "GlobalDefines.h"

// são os modos de operação (de acordo com o datasheet)
typedef enum
{
	MODE_NORMAL       = 0,
	MODE_WAKE_UP      = 1,
	MODE_POWER_SAVING = 2,
	MODE_SLEEP_CONFIG = 3
} LoraMode;

// Tabela de Baud Rate

typedef enum
{
	LORA_BAUD_1200   = 0b000,
	LORA_BAUD_2400   = 0b001,
	LORA_BAUD_4800   = 0b010,
	LORA_BAUD_9600   = 0b011, // Padrão
	LORA_BAUD_19200  = 0b100,
	LORA_BAUD_38400  = 0b101,
	LORA_BAUD_57600  = 0b110,
	LORA_BAUD_115200 = 0b111
} LoraBaudRate;

// Tabela de Air Data Rate

typedef enum {
    LORA_AIR_0_3K    = 0b000,
    LORA_AIR_1_2K    = 0b001,
    LORA_AIR_2_4K    = 0b010, // Padrão
    LORA_AIR_4_8K    = 0b011,
    LORA_AIR_9_6K    = 0b100,
    LORA_AIR_19_2K_A = 0b101
} LoraAirRate;

// Paridade do UART
typedef enum {
    LORA_PARITY_8N1 = 0b00, // 8 bits, Sem paridade, 1 stop (Padrão)
    LORA_PARITY_8O1 = 0b01, // 8 bits, Ímpar (Odd), 1 stop
    LORA_PARITY_8E1 = 0b10  // 8 bits, Par (Even), 1 stop
} LoraParity;

// Tabela de Potência de Transmissão

typedef enum {
    LORA_POWER_30DBM = 0b00, // 1W (Padrão)
    LORA_POWER_27DBM = 0b01,
    LORA_POWER_24DBM = 0b10,
    LORA_POWER_21DBM = 0b11
} LoraPower;

// Se o dado é permanente ou não
typedef enum {
    LORA_SAVE_PERMANENT = 0xC0,
    LORA_SAVE_TEMP      = 0xC2
} LoraSaveMode;

// Modo de Transmissão (transparente envia para todos no mesmo canal, e o fixo para um endereço específico)
typedef enum {
    LORA_MODE_TRANSPARENT = 0,
    LORA_MODE_FIXED       = 1
} LoraFixedMode;

// Modo dos Pinos IO
typedef enum {
    LORA_IO_OPEN_COLLECTOR = 0, // Coletor aberto
    LORA_IO_PUSH_PULL      = 1  // Push-Pull
} LoraIODriveMode;

// Tempo de Wake-Up

typedef enum {
    LORA_WAKEUP_250MS  = 0b000, // Padrão
    LORA_WAKEUP_500MS  = 0b001,
    LORA_WAKEUP_750MS  = 0b010,
    LORA_WAKEUP_1000MS = 0b011,
    LORA_WAKEUP_1250MS = 0b100,
    LORA_WAKEUP_1500MS = 0b101,
    LORA_WAKEUP_1750MS = 0b110,
    LORA_WAKEUP_2000MS = 0b111
} LoraWakeUpTime;

// Correção de Erro FEC

typedef enum {
    LORA_FEC_OFF = 0,
    LORA_FEC_ON  = 1
} LoraFEC;

typedef struct
{
	uint8_t airDataRate  : 3;
	uint8_t uartBaudRate : 3;
	uint8_t uartParity   : 2;
} SPED_s;

typedef struct
{
	uint8_t transmissionPower : 2;
	uint8_t fecSwitch         : 1;
    uint8_t wakeupTime        : 3;
    uint8_t ioDriveMode       : 1;
    uint8_t fixedTransmission : 1;
} OPTION_s;

typedef struct
{
	uint8_t  head;
	uint8_t  addh;
    uint8_t  addl;
    SPED_s   sped;
	uint8_t  chan;
    OPTION_s option;
} LoraConfig_s;
// São os comandos para configuração (específicos do modo 3, sleep_config)

#define E32_CMD_SAVE_CONFIG  0xC0
#define E32_CMD_READ_CONFIG  0xC1
#define E32_CMD_TEMP_CONFIG  0xC2
#define E32_CMD_READ_VERSION 0xC3
#define E32_CMD_RESET        0xC4

#define E32_MAX_TX_BUFFER    255
#define E32_MAX_RX_BUFFER    512
#define E32_TX_TIMEOUT       1000
#define E32_AUX_TIMEOUT      1000

class LORA {
public:
	LORA(UART_HandleTypeDef* huart, PinName aux, PinName m0, PinName m1);
	~LORA();

	HAL_StatusTypeDef init();

	HAL_StatusTypeDef sendMessage(uint16_t address, uint8_t channel, uint8_t* data, uint8_t lenght);
	HAL_StatusTypeDef sendBroadcastMessage(uint8_t channel, uint8_t* data, uint8_t lenght);
	bool isTxReady();
	void handleTxInterrupt();

	HAL_StatusTypeDef enableReception();
	HAL_StatusTypeDef disableReception();

	uint16_t readData(uint8_t* userBuffer, uint16_t maxSize);
	const bool isDataAvailable();
	void handleInterrupt(uint16_t Size);

    HAL_StatusTypeDef setConfig(LoraConfig_s config);
    HAL_StatusTypeDef readConfig(LoraConfig_s* config);
    HAL_StatusTypeDef resetModule();

private:
	UART_HandleTypeDef* _huart;
	PinName             _aux;
	PinName             _m0;
	PinName             _m1;

	uint8_t rxBuffer[E32_MAX_RX_BUFFER];
	uint8_t txBuffer[E32_MAX_TX_BUFFER];

	volatile bool txBusy;
	volatile bool dataAvailableFlag;

	volatile uint16_t lastPacketSize;

    HAL_StatusTypeDef setMode(LoraMode mode);
    HAL_StatusTypeDef waitForAuxHigh(uint32_t timeout);
    void printConfig(LoraConfig_s& config);
};

#endif /* LORA_E32_LORA_H_ */
