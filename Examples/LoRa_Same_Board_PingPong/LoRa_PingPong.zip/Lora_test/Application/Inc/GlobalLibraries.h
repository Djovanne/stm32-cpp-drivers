/*
 * GlobalLibraries.h
 *
 *  Created on: Jan 15, 2026
 *      Author: giova
 */

#include <App_main.hh>
#include "main.h"
#include <stdio.h>
#include <string.h>

#include "LORA.hh"
#include "GlobalDefines.h"
