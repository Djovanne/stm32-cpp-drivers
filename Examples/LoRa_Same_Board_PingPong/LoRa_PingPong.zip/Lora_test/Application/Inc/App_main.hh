/*
 * App_main.h
 *
 *  Created on: Aug 31, 2025
 *      Author: giova
 */

#ifndef APP_MAIN_APP_MAIN_H_
#define APP_MAIN_APP_MAIN_H_

#ifdef __cplusplus
extern "C" {
#endif

void App_main();

#ifdef __cplusplus
}
#endif

#endif /* APP_MAIN_APP_MAIN_H_ */
