################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/BSP/Components/teseo_liv3f/teseo_liv3f.c \
../Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_i2c.c \
../Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_queue.c \
../Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_uart.c 

C_DEPS += \
./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f.d \
./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_i2c.d \
./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_queue.d \
./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_uart.d 

OBJS += \
./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f.o \
./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_i2c.o \
./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_queue.o \
./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_uart.o 


# Each subdirectory must supply rules for building sources it contributes
Drivers/BSP/Components/teseo_liv3f/%.o Drivers/BSP/Components/teseo_liv3f/%.su Drivers/BSP/Components/teseo_liv3f/%.cyclo: ../Drivers/BSP/Components/teseo_liv3f/%.c Drivers/BSP/Components/teseo_liv3f/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/giova/OneDrive/Documentos/Jupiter/codigos/Fetcher_code/teste_BLE/Application/Inc" -I../FATFS/Target -I../FATFS/App -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/Third_Party/FatFs/src -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I../GNSS/App -I../GNSS/Target -I../Drivers/BSP/custom -I../Middlewares/ST/lib_gnss/LibGNSS/Inc -I../Middlewares/ST/lib_gnss/LibNMEA/Inc -I../Drivers/BSP/Components/teseo_liv3f -I../Drivers/BSP/GNSS1A1 -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-BSP-2f-Components-2f-teseo_liv3f

clean-Drivers-2f-BSP-2f-Components-2f-teseo_liv3f:
	-$(RM) ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f.cyclo ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f.d ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f.o ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f.su ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_i2c.cyclo ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_i2c.d ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_i2c.o ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_i2c.su ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_queue.cyclo ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_queue.d ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_queue.o ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_queue.su ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_uart.cyclo ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_uart.d ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_uart.o ./Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_uart.su

.PHONY: clean-Drivers-2f-BSP-2f-Components-2f-teseo_liv3f

