################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/BSP/GNSS1A1/gnss1a1_gnss.c 

C_DEPS += \
./Drivers/BSP/GNSS1A1/gnss1a1_gnss.d 

OBJS += \
./Drivers/BSP/GNSS1A1/gnss1a1_gnss.o 


# Each subdirectory must supply rules for building sources it contributes
Drivers/BSP/GNSS1A1/%.o Drivers/BSP/GNSS1A1/%.su Drivers/BSP/GNSS1A1/%.cyclo: ../Drivers/BSP/GNSS1A1/%.c Drivers/BSP/GNSS1A1/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/giova/OneDrive/Documentos/Jupiter/codigos/Fetcher_code/teste_BLE/Application/Inc" -I../FATFS/Target -I../FATFS/App -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/Third_Party/FatFs/src -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I../GNSS/App -I../GNSS/Target -I../Drivers/BSP/custom -I../Middlewares/ST/lib_gnss/LibGNSS/Inc -I../Middlewares/ST/lib_gnss/LibNMEA/Inc -I../Drivers/BSP/Components/teseo_liv3f -I../Drivers/BSP/GNSS1A1 -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-BSP-2f-GNSS1A1

clean-Drivers-2f-BSP-2f-GNSS1A1:
	-$(RM) ./Drivers/BSP/GNSS1A1/gnss1a1_gnss.cyclo ./Drivers/BSP/GNSS1A1/gnss1a1_gnss.d ./Drivers/BSP/GNSS1A1/gnss1a1_gnss.o ./Drivers/BSP/GNSS1A1/gnss1a1_gnss.su

.PHONY: clean-Drivers-2f-BSP-2f-GNSS1A1

