################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Application/Src/App_main.cpp \
../Application/Src/DigitalIn.cpp \
../Application/Src/DigitalOut.cpp \
../Application/Src/HM10.cpp \
../Application/Src/Timer.cpp 

C_SRCS += \
../Application/Src/USBSerial.c 

C_DEPS += \
./Application/Src/USBSerial.d 

OBJS += \
./Application/Src/App_main.o \
./Application/Src/DigitalIn.o \
./Application/Src/DigitalOut.o \
./Application/Src/HM10.o \
./Application/Src/Timer.o \
./Application/Src/USBSerial.o 

CPP_DEPS += \
./Application/Src/App_main.d \
./Application/Src/DigitalIn.d \
./Application/Src/DigitalOut.d \
./Application/Src/HM10.d \
./Application/Src/Timer.d 


# Each subdirectory must supply rules for building sources it contributes
Application/Src/%.o Application/Src/%.su Application/Src/%.cyclo: ../Application/Src/%.cpp Application/Src/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/giova/OneDrive/Documentos/Jupiter/codigos/Fetcher_code/teste_BLE/Application/Inc" -I../FATFS/Target -I../FATFS/App -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/Third_Party/FatFs/src -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I../GNSS/App -I../GNSS/Target -I../Drivers/BSP/custom -I../Middlewares/ST/lib_gnss/LibGNSS/Inc -I../Middlewares/ST/lib_gnss/LibNMEA/Inc -I../Drivers/BSP/Components/teseo_liv3f -I../Drivers/BSP/GNSS1A1 -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
Application/Src/%.o Application/Src/%.su Application/Src/%.cyclo: ../Application/Src/%.c Application/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/giova/OneDrive/Documentos/Jupiter/codigos/Fetcher_code/teste_BLE/Application/Inc" -I../FATFS/Target -I../FATFS/App -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/Third_Party/FatFs/src -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I../GNSS/App -I../GNSS/Target -I../Drivers/BSP/custom -I../Middlewares/ST/lib_gnss/LibGNSS/Inc -I../Middlewares/ST/lib_gnss/LibNMEA/Inc -I../Drivers/BSP/Components/teseo_liv3f -I../Drivers/BSP/GNSS1A1 -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Application-2f-Src

clean-Application-2f-Src:
	-$(RM) ./Application/Src/App_main.cyclo ./Application/Src/App_main.d ./Application/Src/App_main.o ./Application/Src/App_main.su ./Application/Src/DigitalIn.cyclo ./Application/Src/DigitalIn.d ./Application/Src/DigitalIn.o ./Application/Src/DigitalIn.su ./Application/Src/DigitalOut.cyclo ./Application/Src/DigitalOut.d ./Application/Src/DigitalOut.o ./Application/Src/DigitalOut.su ./Application/Src/HM10.cyclo ./Application/Src/HM10.d ./Application/Src/HM10.o ./Application/Src/HM10.su ./Application/Src/Timer.cyclo ./Application/Src/Timer.d ./Application/Src/Timer.o ./Application/Src/Timer.su ./Application/Src/USBSerial.cyclo ./Application/Src/USBSerial.d ./Application/Src/USBSerial.o ./Application/Src/USBSerial.su

.PHONY: clean-Application-2f-Src

