################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Middlewares/ST/lib_gnss/LibNMEA/Src/NMEA_parser.c 

C_DEPS += \
./Middlewares/ST/lib_gnss/LibNMEA/Src/NMEA_parser.d 

OBJS += \
./Middlewares/ST/lib_gnss/LibNMEA/Src/NMEA_parser.o 


# Each subdirectory must supply rules for building sources it contributes
Middlewares/ST/lib_gnss/LibNMEA/Src/%.o Middlewares/ST/lib_gnss/LibNMEA/Src/%.su Middlewares/ST/lib_gnss/LibNMEA/Src/%.cyclo: ../Middlewares/ST/lib_gnss/LibNMEA/Src/%.c Middlewares/ST/lib_gnss/LibNMEA/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/giova/OneDrive/Documentos/Jupiter/codigos/Fetcher_code/teste_BLE/Application/Inc" -I../FATFS/Target -I../FATFS/App -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/Third_Party/FatFs/src -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I../GNSS/App -I../GNSS/Target -I../Drivers/BSP/custom -I../Middlewares/ST/lib_gnss/LibGNSS/Inc -I../Middlewares/ST/lib_gnss/LibNMEA/Inc -I../Drivers/BSP/Components/teseo_liv3f -I../Drivers/BSP/GNSS1A1 -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Middlewares-2f-ST-2f-lib_gnss-2f-LibNMEA-2f-Src

clean-Middlewares-2f-ST-2f-lib_gnss-2f-LibNMEA-2f-Src:
	-$(RM) ./Middlewares/ST/lib_gnss/LibNMEA/Src/NMEA_parser.cyclo ./Middlewares/ST/lib_gnss/LibNMEA/Src/NMEA_parser.d ./Middlewares/ST/lib_gnss/LibNMEA/Src/NMEA_parser.o ./Middlewares/ST/lib_gnss/LibNMEA/Src/NMEA_parser.su

.PHONY: clean-Middlewares-2f-ST-2f-lib_gnss-2f-LibNMEA-2f-Src

