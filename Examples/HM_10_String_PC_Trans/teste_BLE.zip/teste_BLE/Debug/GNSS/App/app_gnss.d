GNSS/App/app_gnss.o: ../GNSS/App/app_gnss.c ../GNSS/App/app_gnss.h \
 ../GNSS/Target/gnss1a1_conf.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h \
 ../Core/Inc/stm32f4xx_hal_conf.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f411xe.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_sd.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_sdmmc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_usb.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd_ex.h \
 ../Core/Inc/custom_bus.h ../Core/Inc/custom_conf.h \
 ../Core/Inc/custom_errno.h ../GNSS/Target/stm32_bus_ex.h \
 ../Core/Inc/custom_conf.h ../Core/Inc/custom_errno.h \
 ../Drivers/BSP/custom/custom.h ../Drivers/BSP/custom/custom_errno.h \
 ../Core/Inc/main.h ../GNSS/Target/teseo_liv3f_conf.h \
 ../Drivers/BSP/GNSS1A1/gnss1a1_gnss.h \
 ../Drivers/BSP/Components/teseo_liv3f/teseo_liv3f.h \
 ../Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_queue.h \
 ../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_data.h \
 ../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_parser.h \
 ../Middlewares/ST/lib_gnss/LibNMEA/Inc/NMEA_parser.h \
 ../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_geofence.h \
 ../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_datalog.h \
 ../GNSS/App/gnss_feature_cfg_data.h \
 ../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_geofence.h \
 ../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_datalog.h
../GNSS/App/app_gnss.h:
../GNSS/Target/gnss1a1_conf.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h:
../Core/Inc/stm32f4xx_hal_conf.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f411xe.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_sd.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_sdmmc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_usb.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pcd_ex.h:
../Core/Inc/custom_bus.h:
../Core/Inc/custom_conf.h:
../Core/Inc/custom_errno.h:
../GNSS/Target/stm32_bus_ex.h:
../Core/Inc/custom_conf.h:
../Core/Inc/custom_errno.h:
../Drivers/BSP/custom/custom.h:
../Drivers/BSP/custom/custom_errno.h:
../Core/Inc/main.h:
../GNSS/Target/teseo_liv3f_conf.h:
../Drivers/BSP/GNSS1A1/gnss1a1_gnss.h:
../Drivers/BSP/Components/teseo_liv3f/teseo_liv3f.h:
../Drivers/BSP/Components/teseo_liv3f/teseo_liv3f_queue.h:
../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_data.h:
../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_parser.h:
../Middlewares/ST/lib_gnss/LibNMEA/Inc/NMEA_parser.h:
../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_geofence.h:
../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_datalog.h:
../GNSS/App/gnss_feature_cfg_data.h:
../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_geofence.h:
../Middlewares/ST/lib_gnss/LibGNSS/Inc/gnss_datalog.h:
