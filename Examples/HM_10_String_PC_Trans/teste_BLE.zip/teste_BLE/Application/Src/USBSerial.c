/*
 * USBSerial.c
 *
 *  Created on: Jan 13, 2026
 *      Author: giova
 */

#include <stdio.h>
#include "usbd_cdc_if.h"
#include "main.h"

extern USBD_HandleTypeDef hUsbDeviceFS;

int _write(int file, char *ptr, int len)
{
	if (hUsbDeviceFS.dev_state != USBD_STATE_CONFIGURED)
	{
		return 0;
	}

	uint8_t result = USBD_OK;
	uint32_t timeout = HAL_GetTick();
	const uint32_t TIMEOUT_MS = 10;

    do {
        result = CDC_Transmit_FS((uint8_t*)ptr, len);

        if (result == USBD_BUSY)
		{
			if ((HAL_GetTick() - timeout) > TIMEOUT_MS)
			{
				return 0;
			}
		}
    } while (result == USBD_BUSY);

    if (result == USBD_OK)
	{
		return len;
	}
	else
	{
		return 0;
	}
}


