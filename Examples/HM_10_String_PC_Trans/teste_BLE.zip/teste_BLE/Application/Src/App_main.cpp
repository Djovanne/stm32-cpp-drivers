/*
 * App_main.cpp
 *
 *  Created on: Jan 7, 2026
 *      Author: giova
 */

#include "GlobalLibraries.h"

HM10* globalBle = nullptr;
DigitalOut* globalLed = nullptr;

uint8_t bleCommand;

int app_main()
{
	static DigitalOut led(LED);
	static HM10 ble(UART_BLE);

	globalBle = &ble;
	globalLed = &led;

	ble.startListening(&bleCommand);

	ble.println("Sistema Iniciado!");
	ble.print("Testando numero: ");
	ble.print(123);
	ble.println(""); // Envia a linha

	while (1){}
}

// Interrupção

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    // Se a interrupção for da UART1 e o objeto existir
    if (huart->Instance == USART1)
    {
    	if(globalBle != nullptr && globalBle != nullptr)
    	{
			switch (bleCommand)
			{
				case 'L':
				case 'l':
					globalLed->write(true); // Liga
					globalBle->println("LED ON");
					break;

				case 'D':
				case 'd':
					globalLed->write(false);   // Desliga
					globalBle->println("LED OFF");
					break;

				case 'T':
				case 't':
					globalLed->toggle();
					break;

				case 'S':
					globalBle->println("Status: Operacional");
					break;

				default:
					break;
			}
    	}
    	globalBle->startListening(&bleCommand);
    }
}
