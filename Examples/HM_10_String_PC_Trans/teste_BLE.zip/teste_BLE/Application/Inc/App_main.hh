/*
 * App_main.hh
 *
 *  Created on: Jan 7, 2026
 *      Author: giova
 */

#ifndef INC_APP_MAIN_HH_
#define INC_APP_MAIN_HH_

#ifdef __cplusplus
extern "C" {
#endif

int app_main();

#ifdef __cplusplus
}
#endif

#endif /* INC_APP_MAIN_HH_ */
