#include "main.h"

// barramento para comunicação

extern UART_HandleTypeDef huart1;

// BLE interface

#define UART_BLE      (&huart1)

#define LED           (PinName){GPIOB, GPIO_PIN_2} //PB_2
//#define BUZZER        (PinName){GPIOB, GPIO_PIN_5} //PB_5

// If debug messages are active, debugPrint is used as printf, otherwise it
// will be treated as an empty function

#define DEBUG_MESSAGES

#ifdef DEBUG_MESSAGES
  #define debugPrint(fmt, ...) printf(fmt, ##__VA_ARGS__)
#else
  #define debugPrint(fmt, ...)
#endif
