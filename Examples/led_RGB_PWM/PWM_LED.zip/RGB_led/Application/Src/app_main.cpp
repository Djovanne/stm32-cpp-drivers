/*
 * app_main.cpp
 *
 *  Created on: Jan 16, 2026
 *      Author: giova
 */

#include <stdio.h>
#include "app_main.hh"
#include "main.h"
#include "usbd_cdc_if.h"
#include "string.h"

extern UART_HandleTypeDef huart2;
extern TIM_HandleTypeDef htim2;

#define MAX_BUFFER 255

void app_main()
{
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);

	uint16_t dc1, dc2, dc3;

	uint32_t delay = HAL_GetTick();
	uint8_t  tempo = 0;
	while(1)
	{
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, dc1);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, dc2);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, dc3);

		if(dc1 < 1000)
			dc1++;
		else if(dc2 < 1000)
			dc2++;
		else if(dc3 < 1000)
			dc3++;
		else
		{
			dc1 = 0;
			dc2 = 0;
			dc3 = 0;
		}

		HAL_Delay(5);

		if((HAL_GetTick()-delay) > 1000)
		{
			printf("se passou %d segundos!\n\r", tempo);
			tempo++;
			delay = HAL_GetTick();
		}
	}
}

extern "C"
{
	int _write(int file, char *ptr, int len)
	{
		//HAL_UART_Transmit(&huart2, (uint8_t*)ptr, len, 1000);
		CDC_Transmit_FS((uint8_t*)ptr, len);
		return len;
	}
}

